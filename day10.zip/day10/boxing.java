// simple example of Autoboxing in Java

public class boxing {
    public static void main(String args[]){
        int a = 50;    // this is the primitive type

        Integer a2= new Integer(a);  // Boxing // here Integer is predefined type or wrapper and creating a2 object 

        Integer a3 = 5; // boxing  // here with the reference Integer , we are directly assigning i.e internally it is doing the same  thing which is done above.

        System.out.println("Using the deprecated method : "+ a2 + "\n " +"Simply directly assigning from version 9 : "+ a3);
    }
    
}

// The automatic conversion of primitive data types into its equivalent Wrapper type( which mean object type ) is known as BOXING .

// object(which mean wrapper type ) to primitive type is UNBOXING ..