public class typeconversion {

    public static void main(String args[]){

        int i = 34;
        byte b = 3;
        float f = 34.3f;
        double d= 343.34;
        short s = 34;

        double g = f;
        System.out.println(g); // automatically converted ...
        byte h =i;
        System.out.println("The value after conversion is : "+h);
        float j = d;
        System.out.println(j);

    }
    
    
}
// automatic conversion happens byte->short->int->long->float->double
/*
 * 
        // Double datatype
        double d = 100.04;
 
        // Explicit type casting by forcefully getting
        // data from long datatype to integer type
        long l = (long)d;
 
        // Explicit type casting
        int i = (int)l;
 
        // Print statements
        System.out.println("Double value " + d);
 
        // While printing we will see that
        // fractional part lost
        System.out.println("Long value " + l);
 
 */