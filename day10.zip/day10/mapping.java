import java.util.*;

public class mapping {
    public static void main(String args[]){
        Map<Integer,String> map = new HashMap<Integer,String>();
        map.put(1,"Vijay");
        map.put(3,"Umesh");
        map.put(2,"kalki");

        // NOw use the map . Entry for set and Iterator

        Set <Map.Entry<Integer,String>> set = map.entrySet();
    
        Iterator<Map.Entry<Integer,String>> itr = set.iterator();

        while(itr.hasNext()){
            Map.Entry e = itr.next(); // no need to type cast
            System.out.println(e.getKey()+" "+e.getValue());
        }
    }
    
}
