
public class staticmethods {

    public static void main(String[] args) {

        load object = new load();  // looks legal but not preferred to class static methods i.e static methods wont use instance variables or object reference of the class and 
        // doesnot allow itself to be used by them. we cannot call static methods with reference or instance variables. but can use class reference.
        load.addInt(43,456);     // preferred
        load.addDouble(45,334, 4);
    }
}

class load {
    public static int addInt(int x, int y) {
        
        return x + y;
    }

    public static double addDouble(double x, double y, double z) {
        return x + y + z;
    }
}
/*Static Method: A static method is a method that belongs to a class, but it does not belong to an instance of that class 
and this method can be called without the instance or object of that class. In the static method, the method can only access 
only static data members and static methods of another class or same class but cannot access non-static methods and variables.
Non-static method: Any method whose definition doesn’t contain the static keyword is a non-static method. In the non-static 
ethod, the method can access static data members and static methods as well as non-static members and method of another class 
or same class, also can change the values of any static data member. */