public class AutoUnBoxing {
    public static void main(String args[]){

        Integer i = new Integer(50);

        if (i < 100){

            System.out.println(i);   // That is , we are not creating any variables to here , it itself print the value by unboxing itself . 

        }
    }
}
