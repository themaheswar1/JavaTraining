


/* simple example of Unboxing in java 
 The automatic conversion of wrapper class type into corresponding primitive type  is 
 known as Unboxing .
*/






public class unboxing {
    public static void main(String args[]){
        
        Integer i = new Integer(50);  // it is the object type (wrapper type ) has a value 
        int a = i;  // here i'm explicitly assigning object type to the primitive type . That's it ! Unboxed the variable .

        System.out.println(a);
    }
    
}


// The types of datatypes are checked at compile time only unlike python where it is checked at runtime . ex: print(type(a)) gives class-int in python
