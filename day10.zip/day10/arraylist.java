import java.util.*;
class arraylist{
    public static void main(String args[]){

        /*he ArrayList class is a resizable array, which can be found in the java.util
         package.

The difference between a built-in array and an ArrayList in Java, is that the 
size of an array cannot be modified (if you want to add or remove elements to/from an array, 
you have to create a new one). 
While elements can be added and removed from an ArrayList whenever you want.  */    
        ArrayList<String> list = new ArrayList<>();
        System.out.println("Size of the Array : "+list.size());
        list.add("ProStar Pawan");
        list.add("Gajaala Ganesh");
        list.add("Karthik Shawarma");
        //list.add(34);
        //list.add(32) this will give you compile error
        String s = list.get(1);  // this method is executed ..
        System.out.println("Element we will get running above method is : "+s+"\n");   // it is printed
        System.out.println("The data in Array list is : "+list);  // you will get the data because ArrayList is iterable defaultly.
        Iterator <String>  itr = list.iterator();  // It is the base interface for your arraylist. list.iterator() reference variable itr runs this . iterator() is a method of Iterator.
        // The iterator() method of ArrayList class in Java Collection Framework is used to get an iterator over the elements in this list in proper sequence.
        while(itr.hasNext()){      // In string we dont know how many caracs or info we are giving , so we must use iterator to iterate over every single object.
            System.out.println(itr.next());
        }
    }
    // In Simple words : You wont have limited size , you can add how many elemnets you need and remove whatever you want 
    // It has many built in methods like .add , .remove to work with elements.
}

/*
 // with integers 
   import java.util.*;
   class TestGenerics{
    public static void main(String args[]){
    ArrayList<Integer> list = new ArrayList<Integer>();
    list.add("23");
    list.add("4353");
    list.add("45");
    list.add("64);
    list.add("944");
    int element = list.get(4);
    System.out.println(element);
    }
   
 */