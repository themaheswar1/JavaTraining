

class main{
    public static void main(String args[]){

        // initialize the generic class with the integer data

        GenericsClass<Integer> intObj = new GenericsClass<>(5);
        System.out.println("Generic class return : "+intObj.getData());
        
    }
}