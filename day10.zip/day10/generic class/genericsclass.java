
// initialize the generics class

class GenericsClass<T> {

    // variable of T type
    private T data;

    public GenericsClass(T data){
        this.data = data;

    }

    // method that return T type variable

    public T getData(){
        return this.data;
    }
       
}

/*Java Generics methods and classes, enables programmer with a single 
method declaration, a set of related methods, a set of related types. Generics also provide 
compile-time type safety which allows programmers to catch invalid types at compile time.
 Generic means parameterized types. Using generics, the idea is to allow any data type to
  be it Integer, String, or any user-defined Datatype and it is possible to create classes
   that work with different data types.

A Generic class simply means that the items or functions in that
 class can be generalized with the parameter(example T) to specify
  that we can add any type as a parameter in place of T like Integer,
   Character, String, Double or any other user-defined type. */
