class AutoBoxing{
    public static void m(int i){
    System.out.println("int");
}
static void m(Integer i){
    System.out.println("Integer : "+i);
    

}

public static void main(String args[]){
    //short s = 30 ; // it short stores 2 bytes of memory
    short s = 34;
    
    m(s);
}
}
   // Whenver the primitive type method not present then only it will autobox it otherwise 
   // the variable normally goes to primitive method ..