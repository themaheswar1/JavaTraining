class SayHello{

public static void main(String args[]){

System.out.println("This is the First and last java class");

}
}
