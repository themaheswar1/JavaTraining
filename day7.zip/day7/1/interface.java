interface Printable{
    void print();
}
               //An interface is a completely "abstract class" that is used to group related methods with empty bodies:
interface Showable{
    void show();
}




// the void methods are used in another classes as they dont return anything in interface as interface is a abstract class
// so the same methods in the interface is used in another class by implementing the methods.
// So you can alter the implementation and content in the methods and use them.

