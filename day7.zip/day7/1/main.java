public class main {
    public static void main(String args[]){
        A object = new A();

        object.show();
        object.print();
    }
}
