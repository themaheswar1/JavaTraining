class A implements Printable,Showable{
    public void print(){
        System.out.println("hello ...........");  

    }
    public void show(){
        System.out.println("Welcome ...");
    }
}


// Multiple Inheritance is done using interfaces ..
// you cannot extend two classes but you can implement two interfaces ; thats how we use multiple inheritance.
// see the first statement.
