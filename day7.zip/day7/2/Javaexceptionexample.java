public class Javaexceptionexample{
    public static void main(String args[]){
        try{
            int data = 100/0;
            System.out.println(data);
        }
        catch(ArithmeticException e){    // e is the instance of the type Arithmeticexception.
            System.out.println(e);

        }
        System.out.println("So That condition is checked and you continue with rest of the code.......");
    }
}



// in 100/10 , the values are checked at runtime . not at compile time . 
// there is no runtime  error handling in system programming.
// runtime error handling is only used in web app etc .. as we dont know what the user is inputting . They should be checked.
// you should indicate the user to change the input which is not feasible.
// arithmeticexception is a predefined class where it stores the the string divide by zero as parameter in the default constructor and prints it when zero is entered as denominator.
// the exception is java.lang.arithmeticexception 