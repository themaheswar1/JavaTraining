public class homework{
    public int Calculator(int x,int y){
        return x+y;

    }
    public double divide(int x, int y) throws ArithmeticException{
        return x/y;
    }
}
class main{
    public static void main(String args[]){

        homework obj = new homework();
        System.out.println(obj.Calculator(3,5));
        
        try{
            System.out.println(obj.divide(4,0));
        }
        catch(ArithmeticException ae){
            System.out.println(ae);
        }
    }
}