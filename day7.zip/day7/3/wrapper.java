// wrapper classes used explicitly from primitive data types to object type etc...
// parseInt is part of integer wrapper class
class wrapper{
    public static void main(String args[]){

        try{
        int data = 100/10;
        String s = " java ";
        System.out.println(s.length());

        String a = "200";
        int i = Integer.parseInt(a);  // value error if it is not string ..
        System.out.println(i);
        // lets check other error or exception
        int arr[] = new int[5];
        arr[6] = 100;
    
    }
    catch(NumberFormatException e){
        System.out.println(e);

        
    }
    catch(NullPointerException e){
        System.out.println(e);
    }
    catch(ArrayIndexOutOfBoundsException e){
        System.out.println(e);
    }
}
}