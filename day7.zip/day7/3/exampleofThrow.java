public class exampleofThrow {
    public static void validate(int age){
        
        
        if(age < 18){
            throw new ArithmeticException("Person is not eligible to vote...");
        }
        else {
            System.out.println("Person is eligible to vote ...");
        }
    }
    public static void main(String args[]){
        try{
            validate(13);
        }
        catch(ArithmeticException e){
            System.out.println(e);

        }

    }
}
// need of throw is you yourself want to throw runtime error without any condition specifying and you want
// your own content to be printed if that exception occurs..


