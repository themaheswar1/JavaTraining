public class BabyDog extends Dog {

    void weep(){
        System.out.println("It is weeping ............");
    }
   
}
