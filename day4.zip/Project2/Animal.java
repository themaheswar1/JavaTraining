class Animal{
    void eat(){
        System.out.println("It is eating...");
    }
}