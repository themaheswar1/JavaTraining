public class Dog extends Animal {
    void bark(){
        System.out.println("It is barking ...");
    }
    
}
