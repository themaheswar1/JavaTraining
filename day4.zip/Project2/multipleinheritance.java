public class multipleinheritance {
    public static void main(String args[]){

        BabyDog object = new BabyDog();  // creating an object in this class and with the object reference dot function we are  inheriting the methods.

    
    object.eat();
    object.bark();
    object.weep();
    
}
    
}
