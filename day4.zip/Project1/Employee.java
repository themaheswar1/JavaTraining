class Employee{
    float salary=88999.0f;
}