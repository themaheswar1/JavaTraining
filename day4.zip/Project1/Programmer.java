public class Programmer extends Employee{

    int bonus=10000;

    
}
