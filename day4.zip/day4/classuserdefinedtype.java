class classuserdefinedtype{
    int rollno;
    String studentname;
    int marks;
}
class Main{
    public static void main(String args[]){
        classuserdefinedtype s1 = new classuserdefinedtype();  // explained in notebook see...
        System.out.println("Value of rollno before assigning is : "+s1.rollno);
        s1.rollno = 2002;
        System.out.println("Value of rollno after assignment is : "+s1.rollno);
        s1.studentname = "Maheswar Reddy";
        s1.marks = 193;

    }
    
}