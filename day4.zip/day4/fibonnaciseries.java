class fibonacciseries{
    static void fibonacci(int N){
        int num1 = 0 ;
        int num2 = 1;
        int counter = 0;   // randomly taking a number to make loop not to exceed the value of N.
        while(counter<N){
            System.out.print(num1+" ");  // as num1 is updating everytime , the last value also represent final fibonacci number.
            int num3 = num2 + num1;
            num1 = num2;
            num2 = num3;
            counter = counter +  1;
        }
    }
    public static void main(String args[]){
        int N = 20;    
        
       fibonacci(N);
    }
}