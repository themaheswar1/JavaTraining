package Inheritance;

public class Programmer extends Employee {
      Programmer p = new Programmer();
      System.out.println(p.salary);
}
