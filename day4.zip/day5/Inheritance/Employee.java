package Inheritance;
public class Employee
 {
   int salary = 343423; 
}
