public class TestThisMethods{
    public static void main(String args[]){
        

        System.out.println(Adder.add(44,46));
        System.out.println(Adder.add(44,346,2));
    }
}
