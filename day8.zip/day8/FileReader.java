import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileReader {
    public static void main(String args[]) throws FileNotFoundException{ // this single throws statement replace the entire try and catch block with conditions.
        File f4 = new File("D:\\JT.txt\\newandnew.txt");
        Scanner input = new Scanner(System.in);
        while(input.hasNextLine()){
            String data = input.nextLine();
            System.out.println(data);
        }
        input.close();
     
    
}
}
    

