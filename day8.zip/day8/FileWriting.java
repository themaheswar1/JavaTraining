import java.io.File;


// import the IOException class to handle errors
import java.io.IOException;


public class FileWriting {
    public static void main(String args[]){
        try{
            File f3 = new File("D:\\JT.txt\\newandnew.txt");
            if(f3.createNewFile()){
                System.out.println("New File Created ......."+f3.getName());
            }
            else {
                System.out.println("File Already exists.....");
            }
        }
        catch(IOException e){
            System.out.println("There is no such file or directory");
            e.printStackTrace();
        }
    }
    
}
