import java.io.FileWriter;
import java.io.IOException;

public class WritingToFile {
    public static void main(String args[]){
        try {
            FileWriter mywriter = new FileWriter("D:\\JT.txt\\newandnew.txt");
            mywriter.write("Files in java might be tricky , but they are not hard as you think , it is fun enough");
            mywriter.close();
            System.out.println("Successfully wrote to the file");

        }catch(IOException e){
            System.out.println("An error occured");
            e.printStackTrace();
        }
    }
}
