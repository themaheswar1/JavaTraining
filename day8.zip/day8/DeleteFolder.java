import java.io.File;
import java.util.Scanner;

public class DeleteFolder {
    public static void main(String args[]){
        String filepath ; 
        Scanner input = new Scanner(System.in);
        System.out.println("Enter directory path to delete the file : ");
        filepath = input.nextLine();// difference between this nextLine and next() is until you press the enter , it will take all the path under single line.
        input.close();

        // create an instance of file for usere given file path
        File f2 = new File(filepath);
        try{

            // call deleteDirectory() method for deleting subfile and sub-directory
            // use delete() method of the file for deleting user given directory

            deleteDirectory(f2);
            f2.delete();
            System.out.println("your directory is deleted successfullyyy");
        }
         catch(Exception e){
            System.out.println(e.getMessage());

         }
    }
    //create deleteDirectory() for deleting the sub-directories..
    public static void deleteDirectory(File file){
         // use listFiles() method for getting sub files
         for(File subFile : file.listFiles()){
            System.out.println(subFile);
            // if the subfile is a folder , recursively call the deleteDirectory() method
            if(subFile.isDirectory()){
                // isDirectory() method is used to check whether subfile is folder or not
                deleteDirectory(subFile);
                System.out.println("Deleted successfully");
            }
            // use delete() method for deleting file and empty folder
            subFile.delete();
            }
         }
    }
    

