// How to create new folder in java
// Import file class

import java.io.File;

// import scanner class
import java.util.Scanner;

public class CreatenewFolderinJava{
    public static void main(String args[]){
        // using scanner class class to get path as input from the user
        System.out.println("Enter the path where you want to create the folder : ");
        Scanner input = new Scanner(System.in);
        String path = input.next(); 
        input.close();

        // using the scanner class to get the name of the folder

        System.out.println("Enter the name of the folder  : ");
        path = path + input.next();

        // instantiate file class
        File f1 = new File(path);

        // creating folder using mkdir() method 
        boolean bool = f1.mkdir();   // true or false to do mkdir method.
        if(bool){
            System.out.println("Folder created successfully");
        }
        else{
            System.out.println("Error found");

        }


    }
}