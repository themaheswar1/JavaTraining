// arrays program in java 
class Testarray{
    public static void main(String args[]){
        int a[] = new int[5];
        a[0] = 23 ; a[1] = 24;a[2] = 43;
        for (int i = 0; i<= a.length;i++){

            System.out.println(a[i]);
        }
    }
}