public class Transposeofmatrix{


    public static void main(String args[]){
     int[][] matrix = {{2,3,4},{5,6,7}};
     for (int[] row : matrix){          //int[]   " refer it as base address or location of data stored"
        System.out.println(row + "  ");  // so you are gonna get the base address of the first single 
        // dimension array and later after that row again points to the second single dimesional array
        // and prints its base address in hexadecimal format in 64 bit machine..
        // here two single dimesional arrays coz two dimesional array is combination of these two 
        // single dimesional arrays..

     }
     System.out.println("The matrix is : ");
     for (int[] row: matrix){
        for(int column:row){
            System.out.print(column + " ");
        }
        System.out.println();
     }
    }
}