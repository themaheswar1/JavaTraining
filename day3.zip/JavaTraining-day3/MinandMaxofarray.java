class MinandMaxofarray{
    static void min(int arr[]){
        int min= arr[0];
        for (int i =1 ; i < arr.length;i++){
            if(min > arr[i])
            min = arr[i];
        }
        System.out.println(min);
    }
    static void max(int arr[]){
        int max= arr[0];
        for (int i =1 ; i < arr.length;i++){
            if(max <arr[i])
            max = arr[i];
        }
        System.out.println(max);
    }
    
    public static void main(String args[]){
        int arr[] = {34,352,23,12,252,346346,53,22}; // initializing and declaring of array
        min(arr);
        max(arr);
        

    }

}