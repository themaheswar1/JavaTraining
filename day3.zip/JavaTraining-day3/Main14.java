// checking if a number is palindrome in java

class Main14{
    public static void main(String args[]){
        int num = 354453;
        int reversedNum = 0;
        int remainder;
        int originalNumber = num;
        while(num !=0){
            remainder = num % 10;                         // 354453 % 10 = 3                                                            // 35445%10= 5
            reversedNum = reversedNum * 10 + remainder;   // 0 * 10 + 3 = 3                                                              // 0 * 10 + 5
            num /= 10;                                   // 354450 /10 = 35445  and again iterates in the loop with the updated value     // 35440 /10 = 3544
        }
        if(originalNumber == reversedNum){                   // here original number is from front and reversedNUm is as we calculated from back , if the same num is repeated , Palindrome..
            System.out.println(originalNumber + " is Palindrome");
        }
        else{
            System.out.println(originalNumber + " is not a Palindrome");
        }

    }
}