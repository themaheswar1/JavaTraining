// for each loop in java
// for each loop syntax 
// for(int i : arr)  

class foreachloop{
    public static void main(String args[])
    {
        int arr[] = {2,45,45354,5352,24525};
        for(int i : arr){                    // In foreach loop , it holds or points to the elements rather than the index of the array . it associates with data of array .
            System.out.println(i);
        }
    }
}