// arrays program in java 
class Testarray{
    public static void main(String args[]){
        int a[] = new int[6];                         //declaration and instatiation
        a[0] = 23 ; a[1] = 24;a[2] = 43;a[3]=34;a[4]=45;a[5]=65;     //initialization
        for (int i = 0; i<= a.length;i++){

            System.out.println(a[i]);


        }
          
        int a1[] = {13,34,5345,322,25626};
        for(int i = 0;i<= a1.length;i++){
            System.out.println(a1[i]);
        }
      }

}