public class returningarraywithmethod {
    static int[] get(){     // here int[] because we are returning the array , so we are giving the address of the array 
        return new int[]{234,32,54,324,22};
    }

    public static void main(String args[]){
        int arr[] = get();
        for (int i =0;i<arr.length;i++){
            System.out.println(arr[i]);
        }
    }
}
