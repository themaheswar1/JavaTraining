public class SingleInheritance {
    public static void main(String args[]){
        Programmer p=new Programmer();
        System.out.println(p.salary);
         System.out.println(p.bonus);
    }
    
}
