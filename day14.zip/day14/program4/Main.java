package program4;



public class Main {
    public static void main(String args[]){
        Table obj = new Table();
        thread1 t1 = new thread1(obj);
        t1.start();

       
        thread2 t2= new thread2(obj);
        t2.start();
    }
    
}
