package program4;

public class thread2 extends Thread{
    Table t;
    public thread2(Table t)
    {
        this.t = t;

    }
    public void run(){
        t.printTable(5);
    }
    
}


