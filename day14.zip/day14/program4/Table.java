package program4;

public class Table {
    void printTable(int n){
        for(int i=1 ; i<11 ; i++){
            System.out.println(n+"*"+i+"="+n*i);
            try{
                Thread.sleep(1000);
            }
            catch(InterruptedException e){
                System.out.println(e);
            }
        }

    }
    
}
