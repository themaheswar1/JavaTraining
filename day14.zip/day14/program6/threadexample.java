package program6;



public class threadexample {
    public static void main(String args[]){
        final PC pc = new PC();

        // create a thread object that calls pc.produce()
        Thread t1 = new Thread(new Runnable(){
            @Override
            public void run(){
               try{
                pc.produce();
               }
               catch(InterruptedException e){
                e.printStackTrace();
               }
            }
        });      // SEE THE BRACKETS AND SEMICOLON HERE CAREFULLY .........
        // create another threda that calls consume();
     Thread t2 = new Thread(new Runnable() {
        @Override
        public void run(){
            try {
                pc.consume();

            }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        }
     });      
       // SEE THE BRACKETS AND SEMICOLON HERE CAREFULLY..............................................
       // start both threads
       t1.start();
       t2.start();
       // t1 finished before t2
      // t1.join();
       //t2.join();
        }

    }

