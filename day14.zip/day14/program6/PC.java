package program6;

import java.util.Scanner;

// PC (produce Consumer) class with produce and consume methods.

public  class PC {  // static classes can't be inherited , and can't have constructor. and the reference should be final type.

    // prints a string and waits for consume()

    public void produce() throws InterruptedException{
        // synchronized block ensures only one thread is executed at a time
        synchronized(this){
            System.out.println("producer thread is running");
            // releases the lock on shared resource
            wait();
            // and waits till some otheer method invokes notify()
            System.out.println("Second thread slept and thread 1 is Resumed .");
        }


    }
    // Sleeps for sometime and waits for a key press. After key is pressed , it notifies produce()
    public void consume() throws InterruptedException{
        // this makes the produce thread to run first
        Thread.sleep(4000);
        Scanner input = new Scanner(System.in);
        synchronized(this){
            System.out.println("Waiting for return key");
            input.nextLine();
            System.out.println("Key is pressed i.e Second thread is started running. and ran . thread task is finished with this print statement..next it will notify the first thread by notify() method.. ");
            // notifies the produce thread that it can wake up 
            notify();
            // Sleep
            Thread.sleep(1500);
        }
    }
    
}
