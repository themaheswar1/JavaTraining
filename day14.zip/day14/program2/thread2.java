package program2;

public class thread2 implements Runnable{  // run is a prototype in --> Runnable ; may be predefined .
    public void run(){
        System.out.println("Thread is running ....");
    }

    
}
