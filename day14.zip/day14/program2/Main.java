package program2;

public class Main {
    
    public static void main(String args[]){

        thread2 t1 = new thread2();
        Thread m1 = new Thread(t1); // here you  shhould pass t1 to the construtor which inturn implements the runnable interface .
        // Using the constructor Thread(runnable r)

        m1.start();
    }
}
