package program1;

public class Main {
    public static void main(String args[]){

        // why we use threads only ?
        // The need of going to multiple threading is becoz one program under execution or one current task under execution , ex : main method , the one thread is taking all the 
        // burden of all the processess .
        // The advantage of going for multiple threading means ex: 10 threads under go processing using cpu , when one thread doesnot need cpu , i.e if thread becomes ideal
        // then immediately another thread takes the  cpu and therefore cpu is used efficiently ..
        // the cpu will under process continuously . for this we use threads .
        // two ways to use thread 
        // 1 . extends
        // 2 . implements 
      
        thread1 t1 = new thread1();
        t1.start();  // starting the thread --> run

        thread2 t2 = new thread2(null);
        t2.start();  // starting the thread --> run

        

    }
    
}
