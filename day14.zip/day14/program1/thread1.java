   package program1;
   class thread1 extends Thread{     // Thread here is a predefined class .
    public void run(){
        System.out.println("Thread 1 is running now ...");
    }
}