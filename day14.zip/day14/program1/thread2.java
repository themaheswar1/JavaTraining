package program1;

import program4.Table;

public class thread2 extends Thread {
    public thread2(Table obj) {
    }

    public void run(){
        System.out.println("Thread 2 is also running now ..");
    }
    
}
