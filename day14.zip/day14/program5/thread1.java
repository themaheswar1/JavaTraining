package program5;

public class thread1 extends Thread{
    Table t;
    thread1(Table t)
    {
        this.t = t;

    }
    public void run(){
        t.printOdd(20);
    }
    
}
