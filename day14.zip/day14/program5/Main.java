package program5;


// program to odd and even numbers alternatively.


public class Main {
    public static void main(String args[]){
        Table obj = new Table();
        thread1 t1 = new thread1(obj);
        t1.start();

       
        thread2 t2= new thread2(obj);
        t2.start();
    }
    
}

// This is unsynchronized threads i.e when one thread is under execution , the second shouldn't interfere.
// just adding keyword synchronized infront of the method declaration , the threads are now synchronized ..
// that is , first the one thread is fully executed and the second one start after the first one is finished .
