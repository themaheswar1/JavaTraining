package program5;

public class Table {
    synchronized void printEven(int n){
        
        
         for(int i=1;i<n;i++){
            if(i % 2 == 0)
            {
                System.out.println(i);
            try{
                Thread.sleep(4000);
            }
            catch(InterruptedException e){
                System.out.println(e);
            }
        }
    }
}
        synchronized void printOdd(int num){
            
         for(int i=1; i< num ;i++){
            if(i % 2 != 0){
                System.out.println(i);
            
            try{
                Thread.sleep(4000);
            }
            catch(InterruptedException e){
                System.out.println(e);
            }

        }
    }

    }
}
    

