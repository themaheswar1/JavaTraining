package program3;

public class NameThread  implements Runnable {
  

  // run is a prototype in --> Runnable ; may be predefined .
    public void run(){
        System.out.println("Thread is running ....");
    }

    
}

