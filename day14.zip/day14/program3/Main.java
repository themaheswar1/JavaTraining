package program3;

public class Main {
    
    public static void main(String args[]){

        NameThread t1 = new NameThread();
        Thread m1 = new Thread(t1,"This is new Thread"); // here you  shhould pass t1 to the construtor which inturn implements the runnable interface .
        // Using the constructor Thread(runnable r)
         
        m1.start();

        String givenName = m1.getName();
        System.out.println(givenName);
        
        NameThread t2 = new NameThread();
        Thread m2 = new Thread(t2,"This is Second new Thread");
        String givenName2 = m2.getName();
        System.out.println(givenName2);
        m2.start();
    }
}
