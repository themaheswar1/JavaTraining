abstract class Shape{
    abstract void draw();   // abstraction is process of hiding the details using access modifiers like making some instace variables private  etc.
    // abstract 
    // a method which is doesnot have implementation is called prototype
    // this type of methods only can become abstract methods
    // class becomes is abstract methods
    // use of abstract classes is to give common prototype
    // abstract classes cannot be instantiated
    // So , the derived classes of abstract class can be instantiated or can create objects..but not abstract class.
    //
}