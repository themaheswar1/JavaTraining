public class main {
    public static void main(String args[]){
     Circle object = new Circle();
     Rectangle object1 = new Rectangle();
     object.draw();
     object1.draw();

     //Shape s = new Shape(); // it gives error as you can make reference of abstract but see below ;
     Shape s = new Rectangle(); // you can create obj type of Shape but reference with the derived class which gives no error.
     s.draw();
    }
    
    
}
