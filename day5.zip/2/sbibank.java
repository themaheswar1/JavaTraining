public class sbibank extends rbibank {
    int getInterestRateofFd(){
        return 9;
    }
    
}
