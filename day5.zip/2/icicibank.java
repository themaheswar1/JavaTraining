public class icicibank extends rbibank{
    int getInterestRateofFd(){
        return 10;
    }
    
}
