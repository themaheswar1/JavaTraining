public class main {
    public static void main(String args[]){
        sbibank s = new sbibank();
        icicibank i = new icicibank();
        rbibank r = new rbibank();
        System.out.println("SBI rate of interest : "+s.getInterestRateofFd());
        System.out.println("SBI rate of interest : " +i.getInterestRateofFd());
        System.out.println("SBI rate of interest : " +r.getInterestRateofFd());


    }

    
}
