class rbibank{
    int getInterestRateofFd(){
        return 6;
    }
}