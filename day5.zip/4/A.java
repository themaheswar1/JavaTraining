// Access Specifiers 
class A{
    private int data = 40;
    void displaydata(){
        System.out.println("value = "+data);
    }
}