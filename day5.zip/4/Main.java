public class Main {
    public static void main(String args[]){
      A obj = new A();
      //System.out.println(obj.data); // Compile Time Error ..
     
    
    
    // So we cannot access that variable outside the class .i.e i cant display the imformation here .

    // To overcome this..
     // Run a method in the same class of variable to display it and call that method in main class
     // it will be displayed..
      obj.displaydata();

    }
}
