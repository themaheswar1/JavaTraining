class Student{
    private int rollno;
    private String studentname;
    public Student(int rollno, String studentname) {
        this.rollno = rollno;
        this.studentname = studentname;
    }
    public int getRollno() {
        return rollno;
    }
    public void setRollno(int rollno) {
        this.rollno = rollno;
    }
    public String getStudentname() {
        return studentname;
    }
    public void setStudentname(String studentname) {
        this.studentname = studentname;
    }

}