public class main {
    public static void main(String args[]){

        Student s1 = new Student(100011, "Kataari Karthik Shawarma");
        System.out.println("Rollno of the student is : "+ s1.getRollno());
        System.out.println("Name of the student is : "+s1.getStudentname()+"\n");

        // so what is getter and setter function used to get private data ?
        // So For all those variables those value , that is you dont want anyone to change it or instantiate it . For all those vaiable we use get and set method.

        s1.setRollno(38234);
        System.out.println("The updated rollno of the student is : "+s1.getRollno());
    }
}


   // So this is like read and write of your private data , i.e to read and updata it..

   //Getter in Java: Getter returns the value (accessors), it returns the value of data type int, String, double, float, etc. 
   //For the program’s convenience, the getter starts with the word “get” followed by the variable name.

//Setter in Java: While Setter sets or updates the value (mutators).
 //It sets the value for any variable used in a class’s programs. and starts with the word “set” followed by the variable name. 
 // Note: In both getter and setter, the first letter of the variable should be capital.