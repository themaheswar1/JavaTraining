public class Bike extends Vehicle {
    void run(){
      System.out.println("This is the second implementation after I change the content of the inherited method , i want that method , but I want to change the content of method");
    }
}
