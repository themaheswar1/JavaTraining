public class Main {
    public static void main(String args[]){

        Bike object = new Bike();
        object.run();
        //Bike.run();          // it gives error saying cannot make a static reference to the non-static method  run() from the type Bike.
    }
}
