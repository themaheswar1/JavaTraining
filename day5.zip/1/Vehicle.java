// Method Over-riding 
class Vehicle{
    void run(){
        System.out.println("This is the first implementation before overriding the method");
    }
}