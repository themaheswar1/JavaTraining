class A{
    private int data = 33;
    private void msg(){
        System.out.println("This method is not accessible .........");
    }
}