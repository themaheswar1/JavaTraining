/*
 * vector uses a dynamic array to store the data elements
 * it is similar to arraylist
 * however , it is synchronized and contains many methods that are not part of collection framework
 */
import java.util.*;

public class vector {
 public static void main(String args[]){
    Vector<String> v = new Vector<String>();
    v.add("Virat");
    v.add("Iyer");
    v.add("Pandya");

    v.addElement("Jaiswal");

    System.out.println(v.capacity());
         String s1 = v.firstElement();
         System.out.println(s1);

         String s2 = v.lastElement();
         System.out.println(s2);

         Iterator<String> itr = v.iterator();
         while(itr.hasNext()){
            System.out.println(itr.next());
         }

}   
}
