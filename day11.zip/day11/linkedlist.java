
// linkedlist implements the collection interface
/*
 * it uses a doubly linked list internally to store the elements  // unlike arraylist where elements are stored dynamically.
 * it can store duplicate elements
 * it maintains the insertion order and is not synchronized
 * the manipulation is fast because no shifting is required
 * 
 */
import java.util.*;

public class linkedlist {

         public static void main(String args[]){
            LinkedList<String> list = new LinkedList<String>();
            list.add("Maheswar Reddy");
            list.add("Salapakshi Ganesh");
            list.add("karthik");
            list.add("Tinks Pavan");

            Iterator<String> itr = list.iterator();
            while(itr.hasNext()){
                System.out.println(itr.next());
            }

            
         }
    }
    

