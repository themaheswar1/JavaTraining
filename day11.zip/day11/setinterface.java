/*
 * set interface in java is present in java.util package
 * it extends the collection interface
 * it represents the unordered set of elements which doesn't allow us to store the duplicate items
 * we can store at most one null value in set 
 * set is imp0lemented by hashset , linkedhashset and treeset.
 * 
 */
/*
 * Hashset class implements set interface 
 * it represents the collection that uses a hash table for storage
 * hashing is used to store the elements in the hashSet
 * it contains unique items
 */
import java.util.Iterator;
import java.util.HashSet;


 class Student{
        
        public Student(String name,int rollno) {     // the constructor with type string name and int rollno
    }
        String name;
        int rollno;
        public String getName() {
            return name;
        }
        public void setName(String name) {
            this.name = name;
        }
        public int getRollno() {
            return rollno;
        }
        public void setRollno(int rollno) {
            this.rollno = rollno;
        }
        
       
     }


public class setinterface{
    public static void main(String args[]){
        
        HashSet<Student> set1 = new HashSet<Student>();
        //Set <String> set2 = new LinkedHashSet<String>();
        //Set <String> set3 = new TreeSet<String>();
        Student object = new Student("Dupicatename",33); // first when without constructor it gave error like constructor with parameters is not there. so every time generate constructor , getters and setters.
        System.out.println(set1.add(object));
     /*set1.add("First Name ");
     set1.add("Second Name");
     set1.add("Third Name");
     set1.add("Fourth name"); */

    /*Iterator <String> itr = set1.iterator();
     while(itr.hasNext()){
        System.out.println(itr.next());
     } */
     
    }
}