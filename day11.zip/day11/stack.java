/*
 * the stack is the subclass of vector
 * it implements the last-in-first-out data structure i.e stack 
 * the stck contains all the of the methods of vector class and also provides its methods like boolean push(),peek() etc
 */
import java.util.*;

public class stack {
    public static void main(String args[]){
        Stack<String> object = new Stack<String>();
        object.push("First Name");
        object.push("Second Name ");
        object.push("Third name");



        Iterator<String> itr = object.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }

        object.pop();   // last in first out is implemented so , third name is removed after one successful pop . 
        System.out.println(object);


     System.out.println(object.peek());
    }
    
}
