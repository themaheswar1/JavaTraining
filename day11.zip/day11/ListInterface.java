import java.util.*;
class ListInterface{
    public static void main(String args[]){

        // creating an object of list interface implemented by the Array list 

        List<Integer> m1 = new ArrayList<Integer>();

        // Adding elements to object of List interface Custom inputs
        m1.add(0,11); // object.add(index,element)
        m1.add(1,12);
        System.out.println("m1 data : "+m1);
        List<Integer> m2 = new ArrayList<Integer>();
        m2.add(1);
        m2.add(2);
        m2.add(3);
        System.out.println("m2 data : "+m2);

        int letsfindindex = m2.indexOf(3);
        System.out.println("The index of the specified value is : "+letsfindindex);

        m1.addAll(1,m2); // adding the second list to the first list and printing it out 
        System.out.println("m1 data : "+m1);
        m1.removeAll(m2);    // remove the already added second list elements from the first list and printing the same first list .
        System.out.println("m1 data : "+m1);
        m1.remove(1);  // Removes element from index 1
        m1.add(34);

        m1.set(0,645); // Replacing the 2nd element of the list with other value and printing the first list m1
        System.out.println(m1);
    }
}
/*
 * USING  the loop for the iteration 
 * for (int i=-0;i< m1.length ; i++){
 * System.out.println(m1.get(i)+"");
 * 
 * }
 * Using the for-each loop for iteration
 * for(int i:m2){
 * System.out.println(i + "");
 * }
 */