package program2oftheday;


    

@FunctionalInterface    // @ called annotation in java to indicate that it is strictly a single prototype.
interface tellit{
    void told(String name);
    
}

