package program2oftheday;



public class lambda {
    public static void main(String args[]){
        int width1 = 33;
        // with lambda we are doing now 
        Drawable d2 = ()->{        // taking interface reference variable// lambda is nothing but nameless function . just adding brackets and -> to point lambda like that..
            System.out.println("Drawing is done with lambda now ......"+width1);
        }; // okka semicolon pettananduk error anta , chooskora nanna neat ga.....
        d2.draw();
        tellit t1 = (name) ->{
         System.out.println("Hello "+name);
        };
        t1.told("Rocky");  // ikkada println pedthey ee error ostundi , The method println(boolean) in the type PrintStream is not applicable for the arguments (void) 
    }
    
    
}

