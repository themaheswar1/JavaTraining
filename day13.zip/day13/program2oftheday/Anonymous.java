package program2oftheday;

public class Anonymous{
    public static void main(String args[]){
        int width = 10;
        // without lambda , Drawable implementation using anonymous class // Let's see the implementation of anonymous classes .
                                          // nothing this is just the simple implementation of the prototypes unlike the previous program which is little complicated.
        Drawable d = new Drawable()  // observe here no semicolon , that is without implements keyword or etc. i successfully used the prototype 
        // this is the use of the anonymous functions.
        {
            public void draw()
            {
                System.out.println("Drawing "+width);
            }
        };
        d.draw();
    }
}