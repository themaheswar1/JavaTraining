package program2oftheday;

interface Drawable {
    public void draw();
    
}
