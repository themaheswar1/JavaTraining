


interface Multiply {
    
     public void multiplied(int n1,int n2);
    
}
