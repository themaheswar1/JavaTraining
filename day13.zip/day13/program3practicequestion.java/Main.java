
public class Main {
    public static void main(String args[]){

        Add obj = (num1,num2)->{
          
            return num1+num2 ;

        };
        obj.added(23,34);

        Multiply obj2 = (n1,n2)->{
            return num1*num2;
    };
       obj2.multiplied(3*6);
    
}
}
