

interface Add {
    
     public void added(int num1,int num2);
     
}
