package program1;

public class functionalinterfaceexample implements sayable {
    public void say(String msg){

        System.out.println(msg);
    }

    
}
