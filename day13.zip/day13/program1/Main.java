package program1;  // you explicitly made the folder , therefore this package must be included in every program.                    

public class Main {
    public static void main(String args[]){
        functionalinterfaceexample obj = new functionalinterfaceexample();
        obj.say("Hello what the HELL are you doing there in my method...");
    }
    
}
