package program1;

@FunctionalInterface    // @ called annotation in java to indicate that it is strictly a single prototype.
interface sayable{
    void say(String msg);// this is the unimplemeted abstract method or prototype  // need of going to the functional interface is because to give single prototype to all the object references. 
    // Apart from that you can also include static and default methods also .
  default void show(){
    System.out.println("Show Method ");
  }
  static void hello(){
    System.out.println("Saying Hello when this method is called");
  }
}