package program4;
import java.io.*;

public class serialization {

    public static void main(String args[]){
        try{
            Student s1  = new Student(233, "He is hero");
            FileOutputStream fout = new FileOutputStream("D:\\file.txt");
            ObjectOutputStream out = new ObjectOutputStream(fout);
            out.writeObject(s1);
            out.flush();
            out.close();
            System.out.print("Success");

        }catch(Exception e){
            System.out.println(e);
        }
    }
}
  

    
    
