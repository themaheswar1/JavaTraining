package program4;

public class Student  {
    int id;
    String name;
    public Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    
}
