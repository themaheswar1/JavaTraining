class Main6{
    public static void main(String args[]){
        int a = 243 ;
        int b = 33;

        System.out.println("addition of a and b is : a+b = "+(a+b));
        System.out.println("Subtraction of a and b is : a-b = "+(a-b));
        
        System.out.println("Division of a and b is : a/b = "+(a/b));
        System.out.println("Modulus of a and b is : a%b = "+(a%b));
        System.out.println("Multiplication of a and b is : a*b = "+(a*b));

    }
}