// Logic Operators
class Main9{
    public static void main(String args[]){
        int a = 34;
        int b = 33;
        int c = 43;
        System.out.println((a>b)&&(a>c));
        System.out.println((a<c)||(b>c));
        System.out.println(!(c<a));
    }
}