// increment and decrement
class Main10{
    public static void main(String args[]){
        int a = 20;
        int b = 23;
        System.out.println("The value of a is : "+a);
        int result1 = ++a;
        System.out.println("The value of a after pre incremented is : " +result1);
        int result2 = a++;
        System.out.println("The value of a after post increment is : "+result2);
    }
}
