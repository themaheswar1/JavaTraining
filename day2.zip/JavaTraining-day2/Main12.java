// hollow square program in java
class Main12{
    public static void main(String args[]){
        int n = 10;
        for (int i = 1;i <=n;i++){
            for (int j =1;j<=n;j++){
                if(i==1 || i== n){
                    System.out.print("*");
                }
                else{
                    if(j==1 || j == n){
                        System.out.print("*");
                    }
                    else{

                        System.out.print(" "); // space is must , as you are printing space 
                    }
                }
            }
              System.out.println(); // iterating the rows with ln as we need to move to new row
        }
       }
}