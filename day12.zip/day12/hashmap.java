import java.util.HashMap;
import java.util.Map;

public class hashmap {
    public static void main(String args[]){
        HashMap<Integer,String> map = new HashMap<Integer,String>();
        map.put(1,"first one");
        map.put(2,"Second one");
        map.put(3,"Third one");

        System.out.println("Iterating the Hashmap");
        for(Map.Entry m : map.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }
        System.out.println();
        map.put(4, "It's the fourth one");
        for(Map.Entry m : map.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }
        
    }
    
}
