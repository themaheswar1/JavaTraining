package book;
import java.util.*;

public class map {
    public static void main(String args[]){
        Map<Integer,book> m = new HashMap<Integer,book>();

        book b1 = new book(101,"wings of fire","Abdul Kalam","India",34254);
        book b2 = new book(2334,"hgasga","wyutoweytiytiw","philippines",345325);

        m.put(1,b1);
        m.put(2,b2);
        
        for(Map.Entry<Integer,book>  entry : m.entrySet()){
            int key = entry.getKey();
            book b = entry.getValue();

            System.out.println(key + " Details : ");
            System.out.println(b.id + " " + b.name + " " + b.author + " "+ b.publisher+" "+b.quantity);
        }
    }
    
    
}
