public class userdefinedexception extends Exception {
    public userdefinedexception (String str){
    super (str); 
    }
    

    
}