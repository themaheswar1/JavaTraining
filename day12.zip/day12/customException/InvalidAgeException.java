public class InvalidAgeException extends Exception {
    public InvalidAgeException (String str){
    super (str); // you are passing string data to the base class. i.e using super means the variable is directly initialised in the base class constructor.
    }

    
}