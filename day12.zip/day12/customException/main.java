public class main {
    public static void main(String args[]){
        //TestCustomException t= new TestCustomException(); no need for object creation as the method we need is static method.
        
        try {
            //t.validate(13);  // this is warning us that static methods should be accessed in static way 
            TestCustomException.validate(20);    // like this . 
        
    } catch (Exception ex) {
        System.out.println("Caught a exception");
        System.out.println("Exception occured "+ex);

        
    }}
    
}
