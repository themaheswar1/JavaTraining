public class TestCustomException {
    static void validate (int age) throws userdefinedexception{
        if(age <18){
            throw new userdefinedexception("number is smaller");// that super string we gave there is used here .. by passing it directly to the exception.

        }else{
            System.out.print("Number is greater");
        }
    }
    
    
}
