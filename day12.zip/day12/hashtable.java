
import java.util.*;
public class hashtable {
    public static void main(String args[]){
        Hashtable<String , Integer> ht = new Hashtable<String,Integer>();

        ht.put("First One ",10);
        ht.put("Second One ",20);

        System.out.println("Size of map is : "+ht.size());
        System.out.println(ht);

        if(ht.containsKey("First One")){
            Integer a = ht.get("First One");
            System.out.println("value for key" + "\"First One : " +a);
            
        }
    }
}
